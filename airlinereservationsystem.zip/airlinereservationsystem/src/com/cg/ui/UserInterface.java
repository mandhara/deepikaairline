package com.cg.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.Reserve;
import com.cg.service.IReserveService;
import com.cg.service.ReserveServiceImpl;

public class UserInterface {
	static int flag=0;
	static IReserveService reserveiterface= null;
	static ReserveServiceImpl reserveimpl= null;
	//static Reserve reserve=null;
	
	public static void main(String[] args) throws ClassNotFoundException {
		Scanner scanner = new Scanner(System.in);
		Reserve reserve= new Reserve();	
	
		//asking user, whether they want to enter as user or admin 0r executive
		
		System.out.println("welcome to Airline Reservation system");
		System.out.println("enter the type of login");
		System.out.println("1 for USER");
		System.out.println("2 for ADMIN");
		System.out.println("3 for EXECUTIVE");
		int option = scanner.nextInt();
		
		//user entered as user
		
		if(option ==1)
		{
			System.out.println("welcome to Airline Reservation system");
			System.out.println("press 1 to place a request for a filght ticket");
			System.out.println("press 2 to view your reservation details");
			System.out.println("press 3 to update your reservation details");
			System.out.println("press 4 to cancel your reservation details");
			int useroption = scanner.nextInt();
			
					if(useroption==1)
					{
						do{
						System.out.println("Book your flight");
						System.out.println("Give city name from where you want departure ");
						String dep_city= scanner.next(); 
						System.out.println("Give city name to where you want to arrive");
						String arr_city= scanner.next(); 
						ArrayList<Reserve> flight=new ArrayList<Reserve>();
						reserveimpl=new ReserveServiceImpl();
						reserve.setDep_city(dep_city);
						reserve.setArr_city(arr_city);
						flight=reserveimpl.inventory(reserve);
						
						if(flight.isEmpty())
							  {
								System.out.println("Sorry....!!!! No flights flights found from "+reserve.getDep_city()+" to "+reserve.getArr_city());
								}
							
						else
							{	
							System.out.println("These are the flights from "+reserve.getDep_city()+" to "+reserve.getArr_city());
							for(Reserve i:flight)
								{
								System.out.println(i.getFlight_no()+" "+i.getDep_city()+" "+i.getArr_city()+" " +i.getDept_date()+" "+i.getDept_time()+" "+i.getArr_city()+" "+i.getArr_time());
								}
							IReserveService seats=new ReserveServiceImpl();
							System.out.println("Enter the flight ID for booking");
							String flight_no=scanner.next();
							reserve.setFlight_no(flight_no);
							System.out.println("e-mail address");
							String email=scanner.next();
							System.out.println("Enter F for first class and B for bussiness class");
							String flightclass=scanner.next();
							reserve.setFlightclass(flightclass);
							System.out.println("Enter the number of passengers");
							int passengers= scanner.nextInt();
							reserve.setPassengers(passengers);
							
							IReserveService check=new ReserveServiceImpl();
							int available=check.checkSeats(reserve);
							
							if(reserve.getPassengers()<=available){
							
							System.out.println("enter credit card details");
							String creditcard=scanner.next();
							System.out.println("Enter the source city");
							String src_city=scanner.next();
							System.out.println("Enter the destination city");
							String dest_city=scanner.next();
							reserve.setFlight_no(flight_no);
							reserve.setEmail(email);
							reserve.setFlightclass(flightclass);
							reserve.setCreditcard(creditcard);
							reserve.setPassengers(passengers);
							reserve.setScr_city(src_city);
							reserve.setDest_city(dest_city);
							int status= seats.booking(reserve);
							if(status==1)
							{
								System.out.println("successfuly booked. Thanks for Booking");
															
							}
							else
							{
								System.out.println("Booking failed");
								
							}
							
							}
						else{
								System.out.println(reserve.getPassengers()+" seats are not available. only "+available+" seats are available");
						}
							System.out.println("Type 1 if you want to continue Booking");
								System.out.println("Type 2 if you want to exit Booking");
								String temp=scanner.next();
								
								if(temp.equals("1")){
									useroption=1;
								}
								else
								{
									System.out.println("your are exited");
									System.exit(0);
								}
							
							}
						}
						while(useroption==1);
						}
				
				///user view for booking details
					
					
					else if(useroption==2)
					{
						System.out.println("Enter Flight number to view your booking details");
						String flightno=scanner.next();
						reserve.setFlight_no(flightno);
						System.out.println("Enter emailId used for booking");
						String email=scanner.next();
						reserve.setEmail(email);
					
						ArrayList<Reserve> view=new ArrayList<Reserve>();
						reserveimpl=new ReserveServiceImpl();
						view=reserveimpl.ViewBooking(reserve);
						
						if(view.isEmpty())
							  {
								System.out.println("Sorry....!!!! no seats are reserved in flight " +reserve.getFlight_no());
								}
							
						else
							{	
							System.out.println("Showing your booking details.");
							for(Reserve i:view)
								{
								
								System.out.println("booking Id: "+i.getBookid());
								System.out.println("Flight Number:  "+i.getFlight_no());
								System.out.println("Email ID: "+i.getEmail());
								System.out.println("No of passengers:"+i.getPassengers());
								System.out.println("Class type :"+i.getClasstype());
								System.out.println("Amount paid: "+i.getFare());
								System.out.println("Seat numbers: "+i.getSeatno());
								System.out.println("Caredit card details "+i.getCreditcard());
								System.out.println("Departure city: "+i.getScr_city());
								System.out.println("Destination city: "+i.getDest_city());
								
								}
							
							}
					
					}

					else if(useroption==3)
					{
						System.out.println("Enter Flight number to update your booking details");
						
						/*BOOKING_ID VARCHAR2(5) PRIMARY KEY, 
						CUST_EMAIL VARCHAR2(20) NOT NULL, NO_OF_PASSENGER NUMBER, CLASS_TYPE  VARCHAR2(10), TOTAL_FARE NUMBER(10,2), SEAT_NUMBER NUMBER,
						 CREDITCARD_INFO VARCHAR2(10), SRC_CITY VARCHAR2(10),
						DEST_CITY VARCHAR2(10), FLIGHT_NO VARCHAR2(5) REFERENCES FLIGHTINFORMATION (FLIGHT_NO));
						*/
						
						System.out.println("Book your flight");
						System.out.println("Give city name from where you want departure ");
						String dep_city= scanner.next(); 
						System.out.println("Give city name to where you want to arrive");
						String arr_city= scanner.next(); 
						ArrayList<Reserve> flight=new ArrayList<Reserve>();
						reserveimpl=new ReserveServiceImpl();
						reserve.setDep_city(dep_city);
						reserve.setArr_city(arr_city);
						flight=reserveimpl.inventory(reserve);
						
						if(flight.isEmpty())
							  {
								System.out.println("Sorry....!!!! No flights flights found from "+reserve.getDep_city()+" to "+reserve.getArr_city());
								}
							
						else
							{	
							System.out.println("These are the flights from "+reserve.getDep_city()+" to "+reserve.getArr_city());
							for(Reserve i:flight)
								{
								System.out.println(i.getFlight_no()+" "+i.getDep_city()+" "+i.getArr_city()+" " +i.getDept_date()+" "+i.getDept_time()+" "+i.getArr_city()+" "+i.getArr_time());
								}
							IReserveService update=new ReserveServiceImpl();
							System.out.println("Enter the flight ID for booking");
							String flight_no=scanner.next();
							reserve.setFlight_no(flight_no);
							System.out.println("e-mail address");
							String email=scanner.next();
							System.out.println("Enter F for first class and B for bussiness class");
							String flightclass=scanner.next();
							reserve.setFlightclass(flightclass);
							System.out.println("Enter the number of passengers");
							int passengers= scanner.nextInt();
							reserve.setPassengers(passengers);
							
							IReserveService check=new ReserveServiceImpl();
							int available=check.checkSeats(reserve);
							
							if(reserve.getPassengers()<=available){
							
							System.out.println("enter credit card details");
							String creditcard=scanner.next();
							System.out.println("Enter the source city");
							String src_city=scanner.next();
							System.out.println("Enter the destination city");
							String dest_city=scanner.next();
							reserve.setFlight_no(flight_no);
							reserve.setEmail(email);
							reserve.setFlightclass(flightclass);
							reserve.setCreditcard(creditcard);
							reserve.setPassengers(passengers);
							reserve.setScr_city(src_city);
							reserve.setDest_city(dest_city);
							int status= update.updatebooking(reserve);
							if(status==1)
							{
								System.out.println("successfuly updated.");
															
							}
							else
							{
								System.out.println("Booking updation failed");
								
							}
							
							}
						else{
								System.out.println(reserve.getPassengers()+" seats are not available. only "+available+" seats are available");
						}
						
						
						}
					}
					else if(useroption==4)
					{
						System.out.println("Enter Flight number to cancel your booking details");
						
						
						
						
						
						}
					
					else
					{
						System.out.println("Please provide valid option");
					}
		}
		
		
		
		
		
		
		
		//user entered as Admin
		else if(option == 2)
		{

			System.out.println("welcome to Airline Reservation system Admin");
			System.out.println("Enter your name");
			String name =scanner.next();
			
			//validating the name. loop terminates only when admin provide name consists of only characters .
			 while(!validName(name))
				{
				System.out.println("Name should contain only characters");
				System.out.println("Enter your name again");
				name =scanner.next();
				}
			
			System.out.println("Enter password(only numbers are allowed and password length should be 6):");
			String password =scanner.next();
			
			//validating the password. loop terminates only when admin provide only a number of length 6.
			while(!validPassword(password))
			{
				System.out.println("Please check the entered password");
				System.out.println("Enter your password again");
				password =scanner.next();
			}
			
			reserve.setName(name);
			reserve.setPassword(password);
			flag=validateAdmin(reserve);
		
				if(flag==1)
					{
						System.out.println(" logged in successfully as ADMIN");
						System.out.println("type 1 for updating new flights");
						System.out.println("type 2 for managing existing flights");
						int adminoption=scanner.nextInt();
						IReserveService insertflight=new ReserveServiceImpl();
						switch(adminoption)
						{
						case 1:
						{
							
							System.out.println("enter flight number");
							String flightno=scanner.next();
							reserve.setFlight_no(flightno);
							
							System.out.println("enter airline name");
							String airline=scanner.next();
							reserve.setAirline(airline);
							
							System.out.println("enter departure city");
							String deptcity=scanner.next();
							reserve.setDep_city(deptcity);
							
							System.out.println("enter arrival city");
							String arrcity=scanner.next();
							reserve.setArr_city(arrcity);
							
							System.out.println("enter departure date");
							String ddate=scanner.next();
							reserve.setDept_date(ddate);
							
							System.out.println("enter arrival date");
							String adate=scanner.next();
							reserve.setArr_date(adate);
							
							System.out.println("enter departure time");
							double dtime=scanner.nextDouble();
							reserve.setDept_time(dtime);
							
							System.out.println("enter arrival time");
							double atime=scanner.nextDouble();
							reserve.setArr_time(atime);
							
							System.out.println("enter number seats in first class");
							int fseats=scanner.nextInt();
							reserve.setFirstseats(fseats);
							
							System.out.println("enter price/seat for first class");
							double fprice=scanner.nextDouble();
							reserve.setFistseatsfare(fprice);
							
							System.out.println("enter number seats in bussiness class");
							int bseats=scanner.nextInt();
							reserve.setBussseats(bseats);
							
							System.out.println("enter price/seat for bussiness class");
							double bprice=scanner.nextDouble();
							reserve.setBussseatsfare(bprice);
							
							int status= insertflight.insertFlight(reserve);
							if(status==1)
							{
								System.out.println("successfuly updated flight details");
															
							}
							else
							{
								System.out.println("flight updation failed");
								
							}
						}//case 1 ends(adminoption)
						
						case 2:
						{
							
							
							
							System.out.println("Enter departure city");
							String depcity=scanner.next();
							reserve.getDep_city();
							
							System.out.println("Enter destination city");
							String arrcity=scanner.next();
							reserve.setArr_city(arrcity);
							
							System.out.println("Enter departure date");
							String depdate=scanner.next();
							reserve.setDept_date(depdate);
							
							System.out.println("Enter arrival date");
							String arrdate=scanner.next();
							reserve.setArr_date(arrdate);
							
							System.out.println("enter departure time");
							double dtime=scanner.nextDouble();
							reserve.setDept_time(dtime);
							
							System.out.println("enter arrival time");
							double atime=scanner.nextDouble();
							reserve.setArr_time(atime);
							

							System.out.println("enter price/seat for first class");
							double fprice=scanner.nextDouble();
							reserve.setFistseatsfare(fprice);
							
							System.out.println("enter price/seat for bussiness class");
							double bprice=scanner.nextDouble();
							reserve.setBussseatsfare(bprice);
							
							System.out.println("enter flight number");
							String flightno=scanner.next();
							reserve.setFlight_no(flightno);
							
							
							int status= insertflight.manageFlight(reserve);
							if(status==1)
							{
								System.out.println("successfuly updated flight details");
															
							}
							else
							{
								System.out.println("flight updation failed");
								
							}
							
							
							
						}//case 2 end
						}//switch case ends(adminoption)
						
					}
				else
					{
						System.out.println("Check your name and password again");
					}
				
				
				
				}
		
		
		
		//user entered as executive
		
		else if (option ==3)
		{
			
			System.out.println("welcome to Airline Reservation system executive");
			System.out.println("Enter your name");
			String name =scanner.next();
			
			//validating the name. loop terminates only when Executive provide name consists of only characters .

			while(!validName(name))
				{
				System.out.println("Name should contain only characters");
				System.out.println("Enter your name again");
				name =scanner.next();
				}
			System.out.println("Enter password(only numbers are allowed and password length should be 6):");
			String password =scanner.next();
			
			
			//validating the password. loop terminates only when Executive provide only a number of length 6.
			while(!validPassword(password))
				{
				System.out.println("Please check the entered password");
				System.out.println("Enter your password again");
				password =scanner.next();
				}
			
			
			
			reserve.setName(name);
			reserve.setPassword(password);
			
			flag= validateExec(reserve);

				if(flag==1)
				{
					System.out.println(" logged in successfully as EXECUTIVE");

					System.out.println("Enter 1 to view flight occupency based on source and destination");
					System.out.println("Enter 2 to view flight occupency based on flying timings");
					int occupencys= scanner.nextInt();
					switch(occupencys){
					case 1:
					{
						System.out.println("Enter the source city");
						String dep_city=scanner.next();
						System.out.println("Enter the destination city");
						String arr_city=scanner.next();
							
						ArrayList<Reserve> occupy=new ArrayList<Reserve>();
						reserveimpl=new ReserveServiceImpl();
						
						
						reserve.setDep_city(dep_city);
						reserve.setArr_city(arr_city);
						
						occupy=reserveimpl.occupency(reserve);
						
						if(occupy.isEmpty())
							  {
								System.out.println("Sorry....!!!! No flights flights found from "+reserve.getDep_city()+" to "+reserve.getArr_city());
								}
							
						else
							{	
							System.out.println("These are the flights from "+reserve.getDep_city()+" to "+reserve.getArr_city());
							for(Reserve i:occupy)
								{
								
								//System.out.println(i.getFlight_no()+" "+i.getFirstseats()+" "+i.getBussseats());
								System.out.println("flight number: "+i.getFlight_no()+"\navailable first class seats: "+i.getFirstseats()+  "\n available bussiness class seats: "+i.getBussseats());
								}
							}
						}//case 1 ends
					case 2:
					{
						System.out.println("Enter flight number");
						String flightno=scanner.next();
						
						System.out.println("enter start time");
						double depttime=scanner.nextDouble();
						
						System.out.println("enter end time");
						double depttime1=scanner.nextDouble();
						
						
						ArrayList<Reserve> occupy2=new ArrayList<Reserve>();
						reserveimpl=new ReserveServiceImpl();
						reserve.setFlight_no(flightno);
						reserve.setDept_time(depttime);
						reserve.setDepttime(depttime1);
						occupy2=reserveimpl.occupency2(reserve);
						
						if(occupy2.isEmpty())
							  {
								System.out.println("Sorry....!!!! No flights flights found between "+reserve.getDept_time()+" and "+reserve.getDepttime());
								}
							
						else
							{	
							
							System.out.println("These are the flights from "+reserve.getDept_time()+" to "+reserve.getDepttime());
							for(Reserve i:occupy2)
								{
								
								//System.out.println(i.getFlight_no()+" "+i.getFirstseats()+" "+i.getBussseats());
								System.out.println("flight number: "+i.getFlight_no()+"\navailable first class seats: "+i.getFirstseats()+  "\n available bussiness class seats: "+i.getBussseats());
								}
							}
						
						
						
					}//case 2 ends
					}
				}
				else
				{
					System.out.println("Check your name and password again");
				}
		}
		else
		{
			
				System.out.println("please specify the exact option");
		}
		
		

		
		scanner.close();
		
	
	}
	
	
	//method to validate whether the entered password matches the required pattern
	public static boolean validPassword(String password) {
		IReserveService service=new ReserveServiceImpl();
		return service.validPassword(password);
	}

	//method to validate whether the entered name matches the required pattern
	public static boolean validName(String name) {
		IReserveService service=new ReserveServiceImpl();
		return service.validName(name);
	}

	public static int validateAdmin(Reserve reserve)
	{
		IReserveService service=new ReserveServiceImpl();
		
		return service.authenticateAdmin(reserve);
   }
	
	public static int validateExec(Reserve reserve)
	{
		IReserveService service=new ReserveServiceImpl();
		
		return service.authenticateExec(reserve);	
   }
	
	}
	
	


