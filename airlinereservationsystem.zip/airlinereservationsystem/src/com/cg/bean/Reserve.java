package com.cg.bean;

public class Reserve {
	private String name;
	private String password;
	private String role;
	private String dep_city;
	private String arr_city;
	private double dept_time;
	private double depttime;

	private String dept_date;
	private String flight_no;
	private String arr_date;
	private double arr_time;
	private int firstseats;
	private int bussseats;
	private double fistseatsfare;
	private double bussseatsfare;
	private String airline;
	private String email;
	public String flightclass;
	
	private int passengers;
	private String creditcard;
	private String scr_city;
	private String dest_city;
	private int available;
	private String bookid;
	private String classtype;
	private int seatno;
	private double fare;
	

	public int getavailable() {
		return available;
	}


	public int setavailable(int available) {
		return this.available = available;
	}


	public Reserve(String name, String password, String role, String dep_city,
			String arr_city, double dept_time, String dept_date, String flight_no,
			String arr_date, double arr_time, int firstseats, int bussseats,
			double fistseatsfare, double bussseatsfare, String airline,
		String email, String flightclass, int passengers,
			String creditcard) {
		super();
		this.name = name;
		this.password = password;
		this.role = role;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dept_time = dept_time;
		this.dept_date = dept_date;
		this.flight_no = flight_no;
		this.arr_date = arr_date;
		this.arr_time = arr_time;
		this.firstseats = firstseats;
		this.bussseats = bussseats;
		this.fistseatsfare = fistseatsfare;
		this.bussseatsfare = bussseatsfare;
		this.airline = airline;
		this.email = email;
		this.flightclass = flightclass;
		this.passengers = passengers;
		this.creditcard = creditcard;
	}


	public String getEmail() {
		return email;
	}
	public String getFlightclass() {
		return flightclass;
	}
	public void setFlightclass(String flightclass) {
		this.flightclass = flightclass;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public int getPassengers() {
		return passengers;
	}
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	public String getCreditcard() {
		return creditcard;
	}
	public void setCreditcard(String creditcard) {
		this.creditcard = creditcard;
	}
	public String getArr_date() {
		return arr_date;
	}
	public void setArr_date(String arr_date) {
		this.arr_date = arr_date;
	}
	public double getArr_time() {
		return arr_time;
	}
	public void setArr_time(double arr_time) {
		this.arr_time = arr_time;
	}
	public int getFirstseats() {
		return firstseats;
	}
	public void setFirstseats(int i) {
		this.firstseats = i;
	}
	public int getBussseats() {
		return bussseats;
	}
	public void setBussseats(int bussseats) {
		this.bussseats = bussseats;
	}
	public double getFistseatsfare() {
		return fistseatsfare;
	}
	public void setFistseatsfare(double fistseatsfare) {
		this.fistseatsfare = fistseatsfare;
	}
	public double getBussseatsfare() {
		return bussseatsfare;
	}
	public void setBussseatsfare(double bussseatsfare) {
		this.bussseatsfare = bussseatsfare;
	}
	public String getDept_date() {
		return dept_date;
	}
	public void setDept_date(String dept_date) {
		this.dept_date = dept_date;
	}
	public String getDep_city() {
		return dep_city;
	}
	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}
	public String getArr_city() {
		return arr_city;
	}
	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}
	public double getDept_time() {
		return dept_time;
	}
	public void setDept_time(double dept_time) {
		this.dept_time = dept_time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public Reserve(String name, String password, String role) {
		super();
		this.name = name;
		this.password = password;
		this.role = role;
	
	}
	public Reserve() {
		super();
	}
	public String getFlight_no() {
		return flight_no;
	}
	public void setFlight_no(String flight_no) {
		this.flight_no = flight_no;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getScr_city() {
		return scr_city;
	}
	public void setScr_city(String scr_city) {
		this.scr_city = scr_city;
	}
	public String getDest_city() {
		return dest_city;
	}
	public void setDest_city(String dest_city) {
		this.dest_city = dest_city;
	}


	public String getBookid() {
		return bookid;
	}


	public void setBookid(String string) {
		this.bookid = string;
	}


	public String getClasstype() {
		return classtype;
	}


	public void setClasstype(String classtype) {
		this.classtype = classtype;
	}


	public int getSeatno() {
		return seatno;
	}


	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}


	public double getFare() {
		return fare;
	}


	public void setFare(double fare) {
		this.fare = fare;
	}


	public double getDepttime() {
		return depttime;
	}


	public void setDepttime(double depttime) {
		this.depttime = depttime;
	}


	
	
}
