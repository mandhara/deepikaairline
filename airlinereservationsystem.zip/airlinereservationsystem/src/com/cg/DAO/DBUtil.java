package com.cg.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getConn() throws ClassNotFoundException, SQLException {
		Connection conn=null ;
		//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		conn = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg205",
				"training205");
		return conn;
 } 
}
