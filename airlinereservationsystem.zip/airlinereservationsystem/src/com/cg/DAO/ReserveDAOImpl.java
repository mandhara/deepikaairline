package com.cg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.Reserve;

public class ReserveDAOImpl implements IReserveDAO {
	Connection conn=null;
	int status=0;
	
	// 
	@Override
	public int authenticateAdmin(Reserve reserve) {
		int status=0;
		try {
			conn=DBUtil.getConn();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.SelectQueryAdmin);
			pstmt.setString(1,reserve.getName());
			pstmt.setString(2,reserve.getPassword());
			pstmt.setString(3,"ADMIN");
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				
				String name=rs.getString(1);
				String password=rs.getString(2);
				
				if(name.equals(reserve.getName()) && password.equals(reserve.getPassword()))
				{
					status=1;
					
				}
				else
				{    
					status=0;
				}
						
			}
			
			return status;
		}
		catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
		
		@Override
		public int authenticateExec(Reserve reserve) {
			int status=0;
			try {
				conn=DBUtil.getConn();
				PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.SelectQueryExec);
				pstmt.setString(1,reserve.getName());
				pstmt.setString(2,reserve.getPassword());
				pstmt.setString(3,"EXECUTIVE");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					String name=rs.getString(1);
					String password=rs.getString(2);
					
					if(name.equals(reserve.getName()) && password.equals(reserve.getPassword()))
					{
						status=1;
					}
					else
					{
						status=0;
					}
							
				}
				
				return status;	
			}
		
		catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	   }

		
		
		@Override
		public ArrayList<Reserve> inventory(Reserve reserve) {
			
			ArrayList<Reserve> obj1=new ArrayList<Reserve>();
			try {
				conn=DBUtil.getConn();
				PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.SelectQuerySelectFlight);
				pstmt.setString(1,reserve.getDep_city());
				pstmt.setString(2,reserve.getArr_city());
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()){
					
					Reserve reserve1=new Reserve();
					reserve1.setFlight_no(rs.getString(1));
					reserve1.setAirline(rs.getString(2));
					reserve1.setDep_city(rs.getString(3));
					reserve1.setArr_city(rs.getString(4));
					reserve1.setDept_date(rs.getString(5));
					reserve1.setArr_date(rs.getString(6));
					reserve1.setDept_time(rs.getDouble(7));
					reserve1.setArr_time(rs.getDouble(8));
					reserve1.setFirstseats(rs.getInt(9));
					reserve1.setFistseatsfare(rs.getDouble(10));
					reserve1.setBussseats(rs.getInt(11));
					reserve1.setBussseatsfare(rs.getDouble(12));
					obj1.add(reserve1);
				}
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			} 
			
			return obj1;
		}

		
		
		
		
		@Override
		public int booking(Reserve reserve) 
		{
			int insert=0;
			double fare=0.0;
			
			try {
				
				conn=DBUtil.getConn();
				PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.InsertBookingInfo);
				pstmt.setString(1,reserve.getEmail());
				pstmt.setInt(2,reserve.getPassengers());
				pstmt.setString(3,reserve.getFlightclass());
				if(reserve.getFlightclass().equals("F"))
				{
					
							PreparedStatement preparestatementfare=conn.prepareStatement(IQueryMapper.Firstfare);
							preparestatementfare.setString(1, reserve.getFlight_no());
							ResultSet amount=preparestatementfare.executeQuery();
					
							while(amount.next())
							{
								fare=amount.getDouble(1);
								pstmt.setDouble(4, fare*reserve.getPassengers());
					
			// updating the flight information table with available seats		
								PreparedStatement psseatupdate=conn.prepareStatement(IQueryMapper.UpdateFSeats);
								psseatupdate.setInt(1, reserve.getPassengers());
								psseatupdate.setString(2, reserve.getFlight_no());
								int update = psseatupdate.executeUpdate();
							}
						
						
					
				}
				else if(reserve.getFlightclass().equals("B"))
				{
					
					
					PreparedStatement preparestatementfare=conn.prepareStatement(IQueryMapper.Bussfare);
					preparestatementfare.setString(1, reserve.getFlight_no());
					ResultSet amount=preparestatementfare.executeQuery();
					
					while(amount.next())
					{
						fare=amount.getDouble(1);
						pstmt.setDouble(4, fare*reserve.getPassengers());
		// updating the flight information table with available seats
						PreparedStatement psseatupdate=conn.prepareStatement(IQueryMapper.UpdateBSeats);
						psseatupdate.setInt(1, reserve.getPassengers());
						psseatupdate.setString(2, reserve.getFlight_no());
						int update = psseatupdate.executeUpdate();
						
					}
					
					
					
				}
				pstmt.setString(5,reserve.getCreditcard());
				pstmt.setString(6, reserve.getScr_city());
				pstmt.setString(7,reserve.getDest_city());
				pstmt.setString(8,reserve.getFlight_no());
				
				insert = pstmt.executeUpdate();
				
			}
			catch (ClassNotFoundException | SQLException e) {
					
					e.printStackTrace();
				} 
			return insert;
		
			}

		
		
		@Override
		public int checkSeats(Reserve reserve) {
			int available=0;
			try {
				conn=DBUtil.getConn();
				if(reserve.getFlightclass().equals("F"))
				{
				
				PreparedStatement preparestatementcheck=conn.prepareStatement(IQueryMapper.CheckFSeats);
				preparestatementcheck.setString(1, reserve.getFlight_no());
				ResultSet check=preparestatementcheck.executeQuery();
				
				while(check.next())
				{	
					reserve=new Reserve();
					available=reserve.setavailable(check.getInt(1));
					reserve.setavailable(available);
				}
				}
				else if(reserve.getFlightclass().equals("B"))
				{
					PreparedStatement preparestatementcheck=conn.prepareStatement(IQueryMapper.CheckBSeats);
					preparestatementcheck.setString(1, reserve.getFlight_no());
					ResultSet check=preparestatementcheck.executeQuery();
					while(check.next())
					{	
						reserve=new Reserve();
						available=reserve.setavailable(check.getInt(1));
						//System.out.println(available);
						reserve.setavailable(available);
					}
				}
			}
			 catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}
			
			return available;
		}

		
		
		@Override
		public ArrayList<Reserve> occupency(Reserve reserve) {
			
			ArrayList<Reserve> occupencyarray=new ArrayList<Reserve>();
			try {
					conn=DBUtil.getConn();
					PreparedStatement preparestatementoccupency=conn.prepareStatement(IQueryMapper.occupency);
					
					preparestatementoccupency.setString(1,reserve.getDep_city());
					preparestatementoccupency.setString(2,reserve.getArr_city());
					ResultSet occupency=preparestatementoccupency.executeQuery();
					while(occupency.next()){
						reserve=new Reserve();
						reserve.setFlight_no(occupency.getString(1));
						reserve.setFirstseats(occupency.getInt(2));
						reserve.setBussseats(occupency.getInt(3));
						
					occupencyarray.add(reserve);
					}
					
				} 
				
				catch (SQLException | ClassNotFoundException e) {
					e.printStackTrace();
				}
				
			return occupencyarray;
			
			
		}
		
		//
		
		@Override
		public ArrayList<Reserve> occupency2(Reserve reserve) {
			
			ArrayList<Reserve> occupencyarray2=new ArrayList<Reserve>();
			try {
					conn=DBUtil.getConn();
					PreparedStatement preparestatementoccupency2=conn.prepareStatement(IQueryMapper.occupency2);
					
					preparestatementoccupency2.setString(1,reserve.getFlight_no());
					preparestatementoccupency2.setDouble(2,reserve.getDept_time());
					preparestatementoccupency2.setDouble(3,reserve.getDepttime());
					ResultSet occupency2=preparestatementoccupency2.executeQuery();
					while(occupency2.next()){
						reserve=new Reserve();
						reserve.setFlight_no(occupency2.getString(1));
						reserve.setFirstseats(occupency2.getInt(2));
						reserve.setBussseats(occupency2.getInt(3));
						
					occupencyarray2.add(reserve);
					}
					
				} 
				
				catch (SQLException | ClassNotFoundException e) {
					e.printStackTrace();
				}
				
			return occupencyarray2;
			
		}
		
		
		
      ///
		@Override
		public ArrayList<Reserve> ViewBooking(Reserve reserve) throws ClassNotFoundException {
			ArrayList<Reserve> viewbookingarray=new ArrayList<Reserve>();
				try {
					conn=DBUtil.getConn();
					PreparedStatement preparestatementview=conn.prepareStatement(IQueryMapper.viewbooking);
					preparestatementview.setString(1,reserve.getFlight_no());
					preparestatementview.setString(2,reserve.getEmail());
					ResultSet resultview=preparestatementview.executeQuery();
					while(resultview.next())
						{
						
						reserve=new Reserve();
						reserve.setBookid(resultview.getString(1));
						reserve.setEmail(resultview.getString(2));
						reserve.setPassengers(resultview.getInt(3));
						reserve.setClasstype(resultview.getString(4));
						reserve.setFare(resultview.getDouble(5));
						reserve.setSeatno(resultview.getInt(6));
						reserve.setCreditcard(resultview.getString(7));
						reserve.setScr_city(resultview.getString(8));
						reserve.setDest_city(resultview.getString(9));
						reserve.setFlight_no(resultview.getString(10));
						viewbookingarray.add(reserve);
						}
					} 
				 catch (SQLException e) {
					e.printStackTrace();
				}
				
		
			return viewbookingarray;
		}

		
		@Override
		public int insertFlight(Reserve reserve) {
			int insertf=0;
			
			
			try {
				
				conn=DBUtil.getConn();
				PreparedStatement psinsertflight=conn.prepareStatement(IQueryMapper.insertflight);
			
				psinsertflight.setString(1,reserve.getFlight_no());
				psinsertflight.setString(2,reserve.getAirline());
				psinsertflight.setString(3, reserve.getDep_city());
				psinsertflight.setString(4, reserve.getArr_city());
				psinsertflight.setString(5, reserve.getDept_date());
				psinsertflight.setString(6, reserve.getArr_date());
				psinsertflight.setDouble(7,reserve.getDept_time());
				psinsertflight.setDouble(8, reserve.getArr_time());
				psinsertflight.setInt(9,reserve.getFirstseats());
				psinsertflight.setDouble(10,reserve.getFistseatsfare());
				psinsertflight.setInt(11,reserve.getBussseats());
				psinsertflight.setDouble(12, reserve.getBussseatsfare());
				insertf = psinsertflight.executeUpdate();
				
				
				
				}//try end
			catch(Exception e)
			{
				e.printStackTrace();
			}//catch end
			return insertf;
		}

		@Override
		public int manageFlight(Reserve reserve) {
			
			int insert=0;
			
			try {
				
				conn=DBUtil.getConn();
				PreparedStatement psmanageflight=conn.prepareStatement(IQueryMapper.manageflight);
			
				
				psmanageflight.setString(1, reserve.getDep_city());
				psmanageflight.setString(2, reserve.getArr_city());
				psmanageflight.setString(3, reserve.getDept_date());
				psmanageflight.setString(4, reserve.getArr_date());
				psmanageflight.setDouble(5,reserve.getDept_time());
				psmanageflight.setDouble(6, reserve.getArr_time());
				psmanageflight.setDouble(7,reserve.getFistseatsfare());
				psmanageflight.setDouble(8, reserve.getBussseatsfare());
				psmanageflight.setString(9,reserve.getFlight_no());
				insert = psmanageflight.executeUpdate();
				
				
				
				}//try end
			catch(Exception e)
			{
				e.printStackTrace();
			}//catch end
			return insert;
		}

		@Override
		public int updatebooking(Reserve reserve) {
			
			int update=0;
			double fare=0.0;
			
			try {
				
				conn=DBUtil.getConn();
				PreparedStatement psupdatebooking=conn.prepareStatement(IQueryMapper.updateBooking);
				psupdatebooking.setString(1,reserve.getEmail());
				psupdatebooking.setInt(2,reserve.getPassengers());
				psupdatebooking.setString(3,reserve.getFlightclass());
				if(reserve.getFlightclass().equals("F"))
				{
					
							PreparedStatement preparestatementfare=conn.prepareStatement(IQueryMapper.Firstfare);
							preparestatementfare.setString(1, reserve.getFlight_no());
							ResultSet amount=preparestatementfare.executeQuery();
					
							while(amount.next())
							{
								fare=amount.getDouble(1);
								psupdatebooking.setDouble(4, fare*reserve.getPassengers());
					
			// updating the flight information table with available seats		
								PreparedStatement psseatupdate=conn.prepareStatement(IQueryMapper.UpdateFSeats);
								psseatupdate.setInt(1, reserve.getPassengers());
								psseatupdate.setString(2, reserve.getFlight_no());
								int updatefare = psseatupdate.executeUpdate();
							}
						
						
					
				}
				else if(reserve.getFlightclass().equals("B"))
				{
					
					
					PreparedStatement preparestatementfare=conn.prepareStatement(IQueryMapper.Bussfare);
					preparestatementfare.setString(1, reserve.getFlight_no());
					ResultSet amount=preparestatementfare.executeQuery();
					
					while(amount.next())
					{
						fare=amount.getDouble(1);
						psupdatebooking.setDouble(4, fare*reserve.getPassengers());
		// updating the flight information table with available seats
						PreparedStatement psseatupdate=conn.prepareStatement(IQueryMapper.UpdateBSeats);
						psseatupdate.setInt(1, reserve.getPassengers());
						psseatupdate.setString(2, reserve.getFlight_no());
						int updatefare = psseatupdate.executeUpdate();
						
					}
					
					
					
				}
				psupdatebooking.setString(5,reserve.getCreditcard());
				psupdatebooking.setString(6, reserve.getScr_city());
				psupdatebooking.setString(7,reserve.getDest_city());
				psupdatebooking.setString(8,reserve.getFlight_no());
				
				update = psupdatebooking.executeUpdate();
				
			}
			catch (ClassNotFoundException | SQLException e) {
					
					e.printStackTrace();
				} 
			return update;
		
			
		}
		}		
	

		
		
