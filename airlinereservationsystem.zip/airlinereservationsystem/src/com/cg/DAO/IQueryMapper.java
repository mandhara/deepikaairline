package com.cg.DAO;

public interface IQueryMapper {
public final static String SelectQueryAdmin="select username,password,role from users where username=? and password=? and role=?";
public final static String SelectQueryExec="select username,password,role from users where username=? and password=? and role=?";
public final static String SelectQuerySelectFlight="select * from FLIGHTINFORMATION where dep_city=? and arr_city=?";
public final static String InsertBookingInfo="INSERT INTO BOOKINGINFORMATION VALUES(BOOKING_ID.NEXTVAL,?,?,?,?,0,?,?,?,?)";
public final static String Firstfare="select  FirstSeatFare from FLIGHTINFORMATION WHERE FLIGHT_NO = ?";
public final static String Bussfare="select  BussSeatsFare from FLIGHTINFORMATION WHERE FLIGHT_NO = ?";
public final static String UpdateFSeats="update FLIGHTINFORMATION SET FirstSeats=(FirstSeats-?) where flight_no=?";
public final static String UpdateBSeats="update FLIGHTINFORMATION SET BussSeats=(BussSeats-?) where flight_no=?";
public final static String CheckFSeats="select  FirstSeats from FLIGHTINFORMATION WHERE flight_no=?";
public final static String CheckBSeats="select  BussSeats from FLIGHTINFORMATION WHERE flight_no=?";
public final static String occupency="select flight_no,FirstSeats, BussSeats from FLIGHTINFORMATION WHERE dep_city=? AND arr_city=? ";
public final static String occupency2="select flight_no,FirstSeats, BussSeats from FLIGHTINFORMATION where flight_no=? and dept_time>=? and dept_time<=?";
public final static String viewbooking="select * from BOOKINGINFORMATION WHERE FLIGHT_NO=? and CUST_EMAIL=?";
public final static String insertflight="insert into FLIGHTINFORMATION VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
public final static String manageflight="update FLIGHTINFORMATION set DEP_CITY =?, ARR_CITY=?, DEPT_DATE=?, ARR_DATE =?, DEPT_TIME=?, ARR_TIME=?,FirstSeatFare=?,BussSeatsFare=? where FLIGHT_NO=?";
public final static String updateBooking="update BOOKINGINFORMATION set CUST_EMAIL=?,NO_OF_PASSENGER=?,CLASS_TYPE=?,CREDITCARD_INFO=?,SEAT_NUMBER=0,SRC_CITY=?,DEST_CITY=?,TOTAL_FARE=? where FLIGHT_NO=?";
}


