package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Reserve;

public interface IReserveService {
	
	public abstract  int authenticateAdmin(Reserve reserve);

	public abstract int authenticateExec(Reserve reserve);
	
	public abstract boolean validName(String name);

	public abstract boolean validPassword(String password);
	
	public abstract ArrayList<Reserve> inventory(Reserve reserve);
	public abstract int booking(Reserve reserve);
	public abstract ArrayList<Reserve> occupency(Reserve reserve);
	public abstract ArrayList<Reserve> occupency2(Reserve reserve);
	public abstract int checkSeats(Reserve reserve);
	public abstract ArrayList<Reserve> ViewBooking(Reserve reserve) throws ClassNotFoundException;
	public abstract int insertFlight(Reserve reserve);
	public abstract int manageFlight(Reserve reserve);

	public abstract int updatebooking(Reserve reserve);
}
