package com.cg.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.DAO.ReserveDAOImpl;
import com.cg.bean.Reserve;

public class ReserveServiceImpl implements IReserveService {

	ReserveDAOImpl res=new ReserveDAOImpl();
	
	@Override
	public int authenticateAdmin(Reserve reserve) {
		
		return res.authenticateAdmin(reserve);
	}

	@Override
	public int authenticateExec(Reserve reserve) {
		// TODO Auto-generated method stub
		return res.authenticateExec(reserve);
	}

	@Override
	public boolean validName(String name) {
			Pattern pattern = Pattern.compile("[A-Za-z]{2,}");
			Matcher matcher = pattern.matcher(name);
			return matcher.matches();
	}

	@Override
	public boolean validPassword(String password) {
		Pattern pattern = Pattern.compile("[0-9]{6}");
		Matcher matcher = pattern.matcher(password);
		return matcher.matches();
	}

	@Override
	

	public ArrayList<Reserve> inventory(Reserve reserve) {
		
		return res.inventory(reserve);
	}

	
	@Override
	public int booking(Reserve reserve) {
		return res.booking(reserve);
	}

	@Override
	public ArrayList<Reserve> occupency(Reserve reserve) {
		
		return res.occupency(reserve);
	}

	@Override
	public int checkSeats(Reserve reserve) {
	
		// TODO Auto-generated method stub
		return res.checkSeats(reserve)
				;
	}

	@Override
	public ArrayList<Reserve> ViewBooking(Reserve reserve) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		return res.ViewBooking(reserve);
	}

	@Override
	public ArrayList<Reserve> occupency2(Reserve reserve) {
		// TODO Auto-generated method stub
		return res.occupency2(reserve);
	}

	@Override
	public int insertFlight(Reserve reserve) {
		// TODO Auto-generated method stub
		return res.insertFlight(reserve);
	}

	@Override
	public int manageFlight(Reserve reserve) {
		
		return res.manageFlight(reserve);
	}

	@Override
	public int updatebooking(Reserve reserve) {
		// TODO Auto-generated method stub
		return res.updatebooking(reserve);
	}

	
	
	
}
